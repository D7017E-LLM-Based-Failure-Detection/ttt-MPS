namespace NxtControl.Drawing {
    
    
    public class ProjectBrushes {
        
        public static NxtControl.Drawing.Brush Black;
        
        public static NxtControl.Drawing.Brush CanvasBrush;
        
        public static NxtControl.Drawing.Brush FpBackgroundBrush;
        
        public static NxtControl.Drawing.Brush GroupBoxBrush;
        
        public static NxtControl.Drawing.Brush LogStateBrush;
        
        public static NxtControl.Drawing.Brush RoundKnobBrush;
        
        public static NxtControl.Drawing.Brush RuntimeConnectionBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Base__AbnormalBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Base__AbnormalTextBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Base__ActionReqBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Base__ActiveStateBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Base__FpBackgroundBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Base__PassiveBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Base__PassiveStateBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Base__SAPvNormal;
        
        public static NxtControl.Drawing.Brush SE__App2Base__SwitchButtonTrueBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Base__SymBAInstanceLabelBackground;
        
        public static NxtControl.Drawing.Brush SE__App2Base__SymInfoRearm;
        
        public static NxtControl.Drawing.Brush SE__App2Base__SymInstanceLabelBackground;
        
        public static NxtControl.Drawing.Brush SE__App2Base__SymLabelBackground;
        
        public static NxtControl.Drawing.Brush SE__App2Base__TextBoxInputBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Base__TransitionBrush;
        
        public static NxtControl.Drawing.Brush SE__App2CommonProcess__FpBackgroundBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Conveying__FpBackgroundBrush;
        
        public static NxtControl.Drawing.Brush SE__App2Conveying__SymLabelBackground;
        
        public static NxtControl.Drawing.Brush SE__App2Conveying__TextBoxInputBrush;
        
        public static NxtControl.Drawing.Brush SE__App2SingleLinePowerMonitoring__FpBackgroundBrush;
        
        public static NxtControl.Drawing.Brush SE__App2SingleLinePowerMonitoring__TextBoxInputBrush;
        
        public static NxtControl.Drawing.Brush SE__App2SingleLinePowerMonitoring__TransitionBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__AbnormalBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__AbnormalTextBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__ActionReqBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__ActiveBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__ActiveStateBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__CommandPB;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__CompleteBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__CompletedBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__FpBackgroundBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__PassiveBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__PassiveStateBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__SAPvNormal;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__SymBAInstanceLabelBackground;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__SymInfoRearm;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__SymInstanceLabelBackground;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__SymLabelBackground;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__TextBoxInputBrush;
        
        public static NxtControl.Drawing.Brush SE__AppSequence__TransitionBrush;
        
        public static NxtControl.Drawing.Brush SymBackgroundBrush;
        
        public static NxtControl.Drawing.Brush TextBoxBrush;
        
        public static NxtControl.Drawing.Brush TrackerLineBrush;
        
        public static NxtControl.Drawing.Brush TrackerLineDisabledBrush;
        
        public static NxtControl.Drawing.Brush TrackLineBrush;
        
        public static NxtControl.Drawing.Brush Transparent;
        
        public static NxtControl.Drawing.Brush White;
        
        public static NxtControl.Drawing.Brush TrackerHandleBrush;
        
        public static NxtControl.Drawing.Brush ButtonFalseBrush;
        
        public static NxtControl.Drawing.Brush ButtonTrueBrush;
        
        public static NxtControl.Drawing.Brush ButtonBrush;
        
        public static NxtControl.Drawing.Brush ButtonSwitchBackgroundBrush;
        
        public static NxtControl.Drawing.Brush TrackerBrush;
        
        public static NxtControl.Drawing.Brush TrackerLineBackgroundBrush;
        
        public static NxtControl.Drawing.Brush TrackerHandleDisabledBrush;
        
        public static NxtControl.Drawing.Brush TextBoxReadOnlyBrush;
        
        public static NxtControl.Drawing.Brush ButtonSwitchBrush;
        
        public static NxtControl.Drawing.Brush CheckBoxBrush;
        
        public static NxtControl.Drawing.Brush CanvasTopologyButtonBrush;
        
        public static NxtControl.Drawing.Brush CanvasTopologyButtonCurrentBrush;
        
        public static NxtControl.Drawing.Brush CanvasTopologyRoseBrush;
        
        public static NxtControl.Drawing.Brush CanvasTopologyHeaderBrush;
        
        public static NxtControl.Drawing.Brush CanvasTopologySeparatorBrush;
        
        public static NxtControl.Drawing.Brush ComboBoxArrowBackBrush;
        
        public static NxtControl.Drawing.Brush ComboBoxArrowBackDisabledBrush;
        
        public static NxtControl.Drawing.Brush ComboBoxBrush;
        
        public static NxtControl.Drawing.Brush ComboBoxDisabledBrush;
        
        public static NxtControl.Drawing.Brush FaceplateBrush;
        
        public static NxtControl.Drawing.Brush FpStyleRectangularHandleBrush;
        
        public static NxtControl.Drawing.Brush FpStyleRoundHandleBrush;
        
        public static NxtControl.Drawing.Brush LabelBrush;
        
        public static NxtControl.Drawing.Brush ButtonPushedBrush;
        
        public static NxtControl.Drawing.Brush LedColor;
        
        static ProjectBrushes() {
            Black = NxtControl.Drawing.SystemBrushes.Black;
            CanvasBrush = NxtControl.Drawing.SystemBrushes.CanvasBrush;
            FpBackgroundBrush = NxtControl.Drawing.SystemBrushes.FpBackgroundBrush;
            GroupBoxBrush = NxtControl.Drawing.SystemBrushes.GroupBoxBrush;
            LogStateBrush = NxtControl.Drawing.SystemBrushes.LogStateBrush;
            RoundKnobBrush = NxtControl.Drawing.SystemBrushes.RoundKnobBrush;
            RuntimeConnectionBrush = NxtControl.Drawing.SystemBrushes.RuntimeConnectionBrush;
            SE__App2Base__AbnormalBrush = new NxtControl.Drawing.Brush("SE.App2Base.AbnormalBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("SE.App2Base.Abnormal")), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__AbnormalTextBrush = new NxtControl.Drawing.Brush("SE.App2Base.AbnormalTextBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__ActionReqBrush = new NxtControl.Drawing.Brush("SE.App2Base.ActionReqBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.BlinkColor("SE.App2Base.ActionRequired")), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__ActiveStateBrush = new NxtControl.Drawing.Brush("SE.App2Base.ActiveStateBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__FpBackgroundBrush = new NxtControl.Drawing.Brush("SE.App2Base.FpBackgroundBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("LabelBackColor")), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__PassiveBrush = new NxtControl.Drawing.Brush("SE.App2Base.PassiveBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__PassiveStateBrush = new NxtControl.Drawing.Brush("SE.App2Base.PassiveStateBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(132)), ((byte)(132)), ((byte)(132)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SAPvNormal = new NxtControl.Drawing.Brush("SE.App2Base.SAPvNormal", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("SE.App2Base.SAPvNormal")), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SwitchButtonTrueBrush = new NxtControl.Drawing.Brush("SE.App2Base.SwitchButtonTrueBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(114)), ((byte)(110)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SymBAInstanceLabelBackground = new NxtControl.Drawing.Brush("SE.App2Base.SymBAInstanceLabelBackground", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalBottom, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))),
                                    new NxtControl.Drawing.Color(((byte)(132)), ((byte)(130)), ((byte)(130))),
                                    new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255))),
                                    new NxtControl.Drawing.Color(((byte)(217)), ((byte)(217)), ((byte)(217))),
                                    new NxtControl.Drawing.Color(((byte)(151)), ((byte)(154)), ((byte)(162)))}, new float[] {
                                    0F,
                                    0.23F,
                                    0.48F,
                                    0.72F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SymInfoRearm = new NxtControl.Drawing.Brush("SE.App2Base.SymInfoRearm", new NxtControl.Drawing.Brush(new NxtControl.Drawing.BlinkColor("SE.App2Base.BlSymInfoRearm"), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.Center, NxtControl.Drawing.GradientFillBrightness.Light)), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SymInstanceLabelBackground = new NxtControl.Drawing.Brush("SE.App2Base.SymInstanceLabelBackground", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent")), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SymLabelBackground = new NxtControl.Drawing.Brush("SE.App2Base.SymLabelBackground", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalBottom, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210))),
                                    new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__TextBoxInputBrush = new NxtControl.Drawing.Brush("SE.App2Base.TextBoxInputBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__TransitionBrush = new NxtControl.Drawing.Brush("SE.App2Base.TransitionBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(204)), ((byte)(255)), ((byte)(204)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2CommonProcess__FpBackgroundBrush = new NxtControl.Drawing.Brush("SE.App2CommonProcess.FpBackgroundBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(240)), ((byte)(240)), ((byte)(240)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Conveying__FpBackgroundBrush = new NxtControl.Drawing.Brush("SE.App2Conveying.FpBackgroundBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(240)), ((byte)(240)), ((byte)(240)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Conveying__SymLabelBackground = new NxtControl.Drawing.Brush("SE.App2Conveying.SymLabelBackground", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalBottom, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210))),
                                    new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Conveying__TextBoxInputBrush = new NxtControl.Drawing.Brush("SE.App2Conveying.TextBoxInputBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2SingleLinePowerMonitoring__FpBackgroundBrush = new NxtControl.Drawing.Brush("SE.App2SingleLinePowerMonitoring.FpBackgroundBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(240)), ((byte)(240)), ((byte)(240)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2SingleLinePowerMonitoring__TextBoxInputBrush = new NxtControl.Drawing.Brush("SE.App2SingleLinePowerMonitoring.TextBoxInputBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2SingleLinePowerMonitoring__TransitionBrush = new NxtControl.Drawing.Brush("SE.App2SingleLinePowerMonitoring.TransitionBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(204)), ((byte)(255)), ((byte)(204)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__AbnormalBrush = new NxtControl.Drawing.Brush("SE.AppSequence.AbnormalBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("SE.AppBase.Abnormal")), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__AbnormalTextBrush = new NxtControl.Drawing.Brush("SE.AppSequence.AbnormalTextBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__ActionReqBrush = new NxtControl.Drawing.Brush("SE.AppSequence.ActionReqBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("SE.AppBase.ActionRequired")), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__ActiveBrush = new NxtControl.Drawing.Brush("SE.AppSequence.ActiveBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__ActiveStateBrush = new NxtControl.Drawing.Brush("SE.AppSequence.ActiveStateBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__CommandPB = new NxtControl.Drawing.Brush("SE.AppSequence.CommandPB", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(190)), ((byte)(190)), ((byte)(190)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__CompleteBrush = new NxtControl.Drawing.Brush("SE.AppSequence.CompleteBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__CompletedBrush = new NxtControl.Drawing.Brush("SE.AppSequence.CompletedBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__FpBackgroundBrush = new NxtControl.Drawing.Brush("SE.AppSequence.FpBackgroundBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("LabelBackColor")), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__PassiveBrush = new NxtControl.Drawing.Brush("SE.AppSequence.PassiveBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(132)), ((byte)(132)), ((byte)(132)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__PassiveStateBrush = new NxtControl.Drawing.Brush("SE.AppSequence.PassiveStateBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(132)), ((byte)(132)), ((byte)(132)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SAPvNormal = new NxtControl.Drawing.Brush("SE.AppSequence.SAPvNormal", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("SE.AppBase.SAPvNormal")), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SymBAInstanceLabelBackground = new NxtControl.Drawing.Brush("SE.AppSequence.SymBAInstanceLabelBackground", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalBottom, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))),
                                    new NxtControl.Drawing.Color(((byte)(132)), ((byte)(130)), ((byte)(130))),
                                    new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255))),
                                    new NxtControl.Drawing.Color(((byte)(217)), ((byte)(217)), ((byte)(217))),
                                    new NxtControl.Drawing.Color(((byte)(151)), ((byte)(154)), ((byte)(162)))}, new float[] {
                                    0F,
                                    0.23F,
                                    0.48F,
                                    0.72F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SymInfoRearm = new NxtControl.Drawing.Brush("SE.AppSequence.SymInfoRearm", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("SE.AppBase.BlSymInfoRearm"), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.Center, NxtControl.Drawing.GradientFillBrightness.Light)), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SymInstanceLabelBackground = new NxtControl.Drawing.Brush("SE.AppSequence.SymInstanceLabelBackground", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent")), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SymLabelBackground = new NxtControl.Drawing.Brush("SE.AppSequence.SymLabelBackground", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalBottom, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210))),
                                    new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__TextBoxInputBrush = new NxtControl.Drawing.Brush("SE.AppSequence.TextBoxInputBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)))), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__TransitionBrush = new NxtControl.Drawing.Brush("SE.AppSequence.TransitionBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(204)), ((byte)(255)), ((byte)(204)))), NxtControl.Drawing.DrawingObjectType.Project);
            SymBackgroundBrush = NxtControl.Drawing.SystemBrushes.SymBackgroundBrush;
            TextBoxBrush = NxtControl.Drawing.SystemBrushes.TextBoxBrush;
            TrackerLineBrush = NxtControl.Drawing.SystemBrushes.TrackerLineBrush;
            TrackerLineDisabledBrush = NxtControl.Drawing.SystemBrushes.TrackerLineDisabledBrush;
            TrackLineBrush = NxtControl.Drawing.SystemBrushes.TrackLineBrush;
            Transparent = NxtControl.Drawing.SystemBrushes.Transparent;
            White = NxtControl.Drawing.SystemBrushes.White;
            TrackerHandleBrush = new NxtControl.Drawing.Brush("TrackerHandleBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(230)), ((byte)(230)), ((byte)(230))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(248)), ((byte)(248)), ((byte)(248))),
                                    new NxtControl.Drawing.Color(((byte)(232)), ((byte)(232)), ((byte)(232)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            ButtonFalseBrush = new NxtControl.Drawing.Brush("ButtonFalseBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(110)), ((byte)(110)), ((byte)(110)))), NxtControl.Drawing.DrawingObjectType.Project);
            ButtonTrueBrush = new NxtControl.Drawing.Brush("ButtonTrueBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(168)), ((byte)(231)))), NxtControl.Drawing.DrawingObjectType.Project);
            ButtonBrush = new NxtControl.Drawing.Brush("ButtonBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(110)), ((byte)(110)), ((byte)(110)))), NxtControl.Drawing.DrawingObjectType.Project);
            ButtonSwitchBackgroundBrush = new NxtControl.Drawing.Brush("ButtonSwitchBackgroundBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(185)), ((byte)(185)), ((byte)(185)))), NxtControl.Drawing.DrawingObjectType.Project);
            TrackerBrush = new NxtControl.Drawing.Brush("TrackerBrush", new NxtControl.Drawing.Brush(true), NxtControl.Drawing.DrawingObjectType.Project);
            TrackerLineBackgroundBrush = new NxtControl.Drawing.Brush("TrackerLineBackgroundBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(215)), ((byte)(215)), ((byte)(215)))), NxtControl.Drawing.DrawingObjectType.Project);
            TrackerHandleDisabledBrush = new NxtControl.Drawing.Brush("TrackerHandleDisabledBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(180)), ((byte)(180)), ((byte)(180))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(180)), ((byte)(180)), ((byte)(180))),
                                    new NxtControl.Drawing.Color(((byte)(180)), ((byte)(180)), ((byte)(180)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            TextBoxReadOnlyBrush = new NxtControl.Drawing.Brush("TextBoxReadOnlyBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(220)), ((byte)(220)), ((byte)(220)))), NxtControl.Drawing.DrawingObjectType.Project);
            ButtonSwitchBrush = new NxtControl.Drawing.Brush("ButtonSwitchBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(110)), ((byte)(110)), ((byte)(110)))), NxtControl.Drawing.DrawingObjectType.Project);
            CheckBoxBrush = new NxtControl.Drawing.Brush("CheckBoxBrush", new NxtControl.Drawing.Brush(true), NxtControl.Drawing.DrawingObjectType.Project);
            CanvasTopologyButtonBrush = new NxtControl.Drawing.Brush("CanvasTopologyButtonBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(230)), ((byte)(230)), ((byte)(230))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(245)), ((byte)(245)), ((byte)(245))),
                                    new NxtControl.Drawing.Color(((byte)(235)), ((byte)(235)), ((byte)(235)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            CanvasTopologyButtonCurrentBrush = new NxtControl.Drawing.Brush("CanvasTopologyButtonCurrentBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(168)), ((byte)(231)))), NxtControl.Drawing.DrawingObjectType.Project);
            CanvasTopologyRoseBrush = new NxtControl.Drawing.Brush("CanvasTopologyRoseBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(230)), ((byte)(230)), ((byte)(230))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(245)), ((byte)(245)), ((byte)(245))),
                                    new NxtControl.Drawing.Color(((byte)(235)), ((byte)(235)), ((byte)(235)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            CanvasTopologyHeaderBrush = new NxtControl.Drawing.Brush("CanvasTopologyHeaderBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(230)), ((byte)(230)), ((byte)(230))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(245)), ((byte)(245)), ((byte)(245))),
                                    new NxtControl.Drawing.Color(((byte)(235)), ((byte)(235)), ((byte)(235)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            CanvasTopologySeparatorBrush = new NxtControl.Drawing.Brush("CanvasTopologySeparatorBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(30)), ((byte)(30)), ((byte)(30))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.HorizontalRight, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255))),
                                    new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255))),
                                    new NxtControl.Drawing.Color(((byte)(200)), ((byte)(200)), ((byte)(200))),
                                    new NxtControl.Drawing.Color(((byte)(200)), ((byte)(200)), ((byte)(200)))}, new float[] {
                                    0F,
                                    0.5F,
                                    0.51F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            ComboBoxArrowBackBrush = new NxtControl.Drawing.Brush("ComboBoxArrowBackBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(230)), ((byte)(230)), ((byte)(230))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(245)), ((byte)(245)), ((byte)(245))),
                                    new NxtControl.Drawing.Color(((byte)(235)), ((byte)(235)), ((byte)(235)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            ComboBoxArrowBackDisabledBrush = new NxtControl.Drawing.Brush("ComboBoxArrowBackDisabledBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(230)), ((byte)(230)), ((byte)(230))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(245)), ((byte)(245)), ((byte)(245))),
                                    new NxtControl.Drawing.Color(((byte)(235)), ((byte)(235)), ((byte)(235)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            ComboBoxBrush = new NxtControl.Drawing.Brush("ComboBoxBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("ComboBoxBackColor")), NxtControl.Drawing.DrawingObjectType.Project);
            ComboBoxDisabledBrush = new NxtControl.Drawing.Brush("ComboBoxDisabledBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(220)), ((byte)(220)), ((byte)(220)))), NxtControl.Drawing.DrawingObjectType.Project);
            FaceplateBrush = new NxtControl.Drawing.Brush("FaceplateBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("FaceplateBackColor")), NxtControl.Drawing.DrawingObjectType.Project);
            FpStyleRectangularHandleBrush = new NxtControl.Drawing.Brush("FpStyleRectangularHandleBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(230)), ((byte)(230)), ((byte)(230))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(245)), ((byte)(245)), ((byte)(245))),
                                    new NxtControl.Drawing.Color(((byte)(140)), ((byte)(140)), ((byte)(140)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            FpStyleRoundHandleBrush = new NxtControl.Drawing.Brush("FpStyleRoundHandleBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(230)), ((byte)(230)), ((byte)(230))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
                                    new NxtControl.Drawing.Color(((byte)(245)), ((byte)(245)), ((byte)(245))),
                                    new NxtControl.Drawing.Color(((byte)(140)), ((byte)(140)), ((byte)(140)))}, new float[] {
                                    0F,
                                    1F}))), NxtControl.Drawing.DrawingObjectType.Project);
            LabelBrush = new NxtControl.Drawing.Brush("LabelBrush", new NxtControl.Drawing.Brush(true), NxtControl.Drawing.DrawingObjectType.Project);
            ButtonPushedBrush = new NxtControl.Drawing.Brush("ButtonPushedBrush", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(168)), ((byte)(230)))), NxtControl.Drawing.DrawingObjectType.Project);
            LedColor = new NxtControl.Drawing.Brush("LedColor", new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(90)), ((byte)(90)), ((byte)(90)))), NxtControl.Drawing.DrawingObjectType.Project);
        }
    }
    
    public class ProjectPens {
        
        public static NxtControl.Drawing.Pen Black;
        
        public static NxtControl.Drawing.Pen FpBackgroundPen;
        
        public static NxtControl.Drawing.Pen FpLinePen;
        
        public static NxtControl.Drawing.Pen GroupBoxPen;
        
        public static NxtControl.Drawing.Pen LabelPen;
        
        public static NxtControl.Drawing.Pen SE__App2Base__SAElementFrame;
        
        public static NxtControl.Drawing.Pen SE__App2Base__SAPvAbnormal;
        
        public static NxtControl.Drawing.Pen SE__App2Base__SAPvNormal;
        
        public static NxtControl.Drawing.Pen SE__AppSequence__FrameDefault;
        
        public static NxtControl.Drawing.Pen SE__AppSequence__FrameHighlight;
        
        public static NxtControl.Drawing.Pen SE__AppSequence__SAElementFrame;
        
        public static NxtControl.Drawing.Pen SE__AppSequence__SAPvAbnormal;
        
        public static NxtControl.Drawing.Pen SE__AppSequence__SAPvNormal;
        
        public static NxtControl.Drawing.Pen SymBackgroundPen;
        
        public static NxtControl.Drawing.Pen SymLinePen;
        
        public static NxtControl.Drawing.Pen Transparent;
        
        public static NxtControl.Drawing.Pen White;
        
        public static NxtControl.Drawing.Pen ButtonPen;
        
        public static NxtControl.Drawing.Pen CanvasTopologyButtonPen;
        
        public static NxtControl.Drawing.Pen TrackerHandlePen;
        
        public static NxtControl.Drawing.Pen TrackerLinePen;
        
        public static NxtControl.Drawing.Pen TrackerPen;
        
        public static NxtControl.Drawing.Pen RoundKnobPen;
        
        public static NxtControl.Drawing.Pen TextBoxPen;
        
        public static NxtControl.Drawing.Pen ComboBoxPen;
        
        static ProjectPens() {
            Black = NxtControl.Drawing.SystemPens.Black;
            FpBackgroundPen = NxtControl.Drawing.SystemPens.FpBackgroundPen;
            FpLinePen = NxtControl.Drawing.SystemPens.FpLinePen;
            GroupBoxPen = NxtControl.Drawing.SystemPens.GroupBoxPen;
            LabelPen = NxtControl.Drawing.SystemPens.LabelPen;
            SE__App2Base__SAElementFrame = new NxtControl.Drawing.Pen("SE.App2Base.SAElementFrame", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(114)), ((byte)(114))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SAPvAbnormal = new NxtControl.Drawing.Pen("SE.App2Base.SAPvAbnormal", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(245)), ((byte)(157)), ((byte)(86))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SAPvNormal = new NxtControl.Drawing.Pen("SE.App2Base.SAPvNormal", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(114)), ((byte)(114))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__FrameDefault = new NxtControl.Drawing.Pen("SE.AppSequence.FrameDefault", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(30)), ((byte)(30)), ((byte)(30))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__FrameHighlight = new NxtControl.Drawing.Pen("SE.AppSequence.FrameHighlight", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SAElementFrame = new NxtControl.Drawing.Pen("SE.AppSequence.SAElementFrame", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(114)), ((byte)(114))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SAPvAbnormal = new NxtControl.Drawing.Pen("SE.AppSequence.SAPvAbnormal", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(245)), ((byte)(157)), ((byte)(86))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SAPvNormal = new NxtControl.Drawing.Pen("SE.AppSequence.SAPvNormal", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(114)), ((byte)(114))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            SymBackgroundPen = NxtControl.Drawing.SystemPens.SymBackgroundPen;
            SymLinePen = NxtControl.Drawing.SystemPens.SymLinePen;
            Transparent = NxtControl.Drawing.SystemPens.Transparent;
            White = NxtControl.Drawing.SystemPens.White;
            ButtonPen = new NxtControl.Drawing.Pen("ButtonPen", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            CanvasTopologyButtonPen = new NxtControl.Drawing.Pen("CanvasTopologyButtonPen", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(220)), ((byte)(220)), ((byte)(220))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            TrackerHandlePen = new NxtControl.Drawing.Pen("TrackerHandlePen", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(190)), ((byte)(190)), ((byte)(190))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            TrackerLinePen = new NxtControl.Drawing.Pen("TrackerLinePen", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(190)), ((byte)(190)), ((byte)(190))), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            TrackerPen = new NxtControl.Drawing.Pen("TrackerPen", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            RoundKnobPen = new NxtControl.Drawing.Pen("RoundKnobPen", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("White"), 1F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            TextBoxPen = new NxtControl.Drawing.Pen("TextBoxPen", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("TextBoxPenColor"), 0F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
            ComboBoxPen = new NxtControl.Drawing.Pen("ComboBoxPen", new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("ComboBoxPenColor"), 0F, NxtControl.Drawing.DashStyle.Solid), NxtControl.Drawing.DrawingObjectType.Project);
        }
    }
    
    public class ProjectFonts {
        
        public static NxtControl.Drawing.Font BigCanvasTopologyButtonFont;
        
        public static NxtControl.Drawing.Font CanvasTopologyButtonFont;
        
        public static NxtControl.Drawing.Font HeaderFont;
        
        public static NxtControl.Drawing.Font LabelFont;
        
        public static NxtControl.Drawing.Font RoundKnobValueFont;
        
        public static NxtControl.Drawing.Font SansSerif;
        
        public static NxtControl.Drawing.Font SE__App2Base__FpLabelFont;
        
        public static NxtControl.Drawing.Font SE__App2Base__FpPv;
        
        public static NxtControl.Drawing.Font SE__App2Base__FpText;
        
        public static NxtControl.Drawing.Font SE__App2Base__LabelFont;
        
        public static NxtControl.Drawing.Font SE__App2Base__Pv;
        
        public static NxtControl.Drawing.Font SE__App2Base__Sp;
        
        public static NxtControl.Drawing.Font SE__App2Base__SymBAInstanceLabel;
        
        public static NxtControl.Drawing.Font SE__App2Base__SymExternalControlLabel;
        
        public static NxtControl.Drawing.Font SE__App2Base__SymInstanceLabel;
        
        public static NxtControl.Drawing.Font SE__App2Base__SymPv;
        
        public static NxtControl.Drawing.Font SE__App2Base__SymSp;
        
        public static NxtControl.Drawing.Font SE__App2Base__SymText;
        
        public static NxtControl.Drawing.Font SE__App2Base__Text;
        
        public static NxtControl.Drawing.Font SE__App2CommonProcess__FpPv;
        
        public static NxtControl.Drawing.Font SE__App2CommonProcess__FpText;
        
        public static NxtControl.Drawing.Font SE__App2CommonProcess__LabelFont;
        
        public static NxtControl.Drawing.Font SE__App2CommonProcess__Pv;
        
        public static NxtControl.Drawing.Font SE__App2CommonProcess__Sp;
        
        public static NxtControl.Drawing.Font SE__App2CommonProcess__SymInstanceLabel;
        
        public static NxtControl.Drawing.Font SE__App2CommonProcess__SymPv;
        
        public static NxtControl.Drawing.Font SE__App2Conveying__FpLabelFont;
        
        public static NxtControl.Drawing.Font SE__App2Conveying__FpPv;
        
        public static NxtControl.Drawing.Font SE__App2Conveying__FpSp;
        
        public static NxtControl.Drawing.Font SE__App2Conveying__FpText;
        
        public static NxtControl.Drawing.Font SE__App2Conveying__LabelFont;
        
        public static NxtControl.Drawing.Font SE__App2Conveying__SymText;
        
        public static NxtControl.Drawing.Font SE__App2SingleLinePowerMonitoring__FpSp;
        
        public static NxtControl.Drawing.Font SE__App2SingleLinePowerMonitoring__LabelFont;
        
        public static NxtControl.Drawing.Font SE__App2SingleLinePowerMonitoring__Pv;
        
        public static NxtControl.Drawing.Font SE__App2SingleLinePowerMonitoring__Sp;
        
        public static NxtControl.Drawing.Font SE__App2SingleLinePowerMonitoring__SymInstanceLabel;
        
        public static NxtControl.Drawing.Font SE__App2SingleLinePowerMonitoring__SymPv;
        
        public static NxtControl.Drawing.Font SE__App2SingleLinePowerMonitoring__SymSp;
        
        public static NxtControl.Drawing.Font SE__AppSequence__FpLabelFont;
        
        public static NxtControl.Drawing.Font SE__AppSequence__FpPv;
        
        public static NxtControl.Drawing.Font SE__AppSequence__FpSp;
        
        public static NxtControl.Drawing.Font SE__AppSequence__FpText;
        
        public static NxtControl.Drawing.Font SE__AppSequence__LabelFont;
        
        public static NxtControl.Drawing.Font SE__AppSequence__Pv;
        
        public static NxtControl.Drawing.Font SE__AppSequence__SALabel;
        
        public static NxtControl.Drawing.Font SE__AppSequence__SAPv;
        
        public static NxtControl.Drawing.Font SE__AppSequence__SASp;
        
        public static NxtControl.Drawing.Font SE__AppSequence__Sp;
        
        public static NxtControl.Drawing.Font SE__AppSequence__SymBAInstanceLabel;
        
        public static NxtControl.Drawing.Font SE__AppSequence__SymInstanceLabel;
        
        public static NxtControl.Drawing.Font SE__AppSequence__SymPv;
        
        public static NxtControl.Drawing.Font SE__AppSequence__SymSp;
        
        public static NxtControl.Drawing.Font SE__AppSequence__SymText;
        
        public static NxtControl.Drawing.Font SE__AppSequence__Text;
        
        public static NxtControl.Drawing.Font SE__HwCommon__GroupActiveHeaderFont;
        
        public static NxtControl.Drawing.Font SE__HwCommon__GroupInactiveHeaderFont;
        
        public static NxtControl.Drawing.Font Standard__IoModbus__SymbolCaptionFont;
        
        public static NxtControl.Drawing.Font ButtonFont;
        
        public static NxtControl.Drawing.Font CheckBoxFont;
        
        public static NxtControl.Drawing.Font RoundKnobFont;
        
        public static NxtControl.Drawing.Font TextBoxFont;
        
        public static NxtControl.Drawing.Font ComboBoxFont;
        
        public static NxtControl.Drawing.Font TrackerValueFont;
        
        public static NxtControl.Drawing.Font TrackerFont;
        
        static ProjectFonts() {
            BigCanvasTopologyButtonFont = NxtControl.Drawing.SystemFonts.BigCanvasTopologyButtonFont;
            CanvasTopologyButtonFont = NxtControl.Drawing.SystemFonts.CanvasTopologyButtonFont;
            HeaderFont = NxtControl.Drawing.SystemFonts.HeaderFont;
            LabelFont = NxtControl.Drawing.SystemFonts.LabelFont;
            RoundKnobValueFont = NxtControl.Drawing.SystemFonts.RoundKnobValueFont;
            SansSerif = NxtControl.Drawing.SystemFonts.SansSerif;
            SE__App2Base__FpLabelFont = new NxtControl.Drawing.Font("SE.App2Base.FpLabelFont", new NxtControl.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__FpPv = new NxtControl.Drawing.Font("SE.App2Base.FpPv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__FpText = new NxtControl.Drawing.Font("SE.App2Base.FpText", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__LabelFont = new NxtControl.Drawing.Font("SE.App2Base.LabelFont", new NxtControl.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__Pv = new NxtControl.Drawing.Font("SE.App2Base.Pv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__Sp = new NxtControl.Drawing.Font("SE.App2Base.Sp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SymBAInstanceLabel = new NxtControl.Drawing.Font("SE.App2Base.SymBAInstanceLabel", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SymExternalControlLabel = new NxtControl.Drawing.Font("SE.App2Base.SymExternalControlLabel", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SymInstanceLabel = new NxtControl.Drawing.Font("SE.App2Base.SymInstanceLabel", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SymPv = new NxtControl.Drawing.Font("SE.App2Base.SymPv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SymSp = new NxtControl.Drawing.Font("SE.App2Base.SymSp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__SymText = new NxtControl.Drawing.Font("SE.App2Base.SymText", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Base__Text = new NxtControl.Drawing.Font("SE.App2Base.Text", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2CommonProcess__FpPv = new NxtControl.Drawing.Font("SE.App2CommonProcess.FpPv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2CommonProcess__FpText = new NxtControl.Drawing.Font("SE.App2CommonProcess.FpText", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2CommonProcess__LabelFont = new NxtControl.Drawing.Font("SE.App2CommonProcess.LabelFont", new NxtControl.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2CommonProcess__Pv = new NxtControl.Drawing.Font("SE.App2CommonProcess.Pv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2CommonProcess__Sp = new NxtControl.Drawing.Font("SE.App2CommonProcess.Sp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2CommonProcess__SymInstanceLabel = new NxtControl.Drawing.Font("SE.App2CommonProcess.SymInstanceLabel", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2CommonProcess__SymPv = new NxtControl.Drawing.Font("SE.App2CommonProcess.SymPv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Conveying__FpLabelFont = new NxtControl.Drawing.Font("SE.App2Conveying.FpLabelFont", new NxtControl.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Conveying__FpPv = new NxtControl.Drawing.Font("SE.App2Conveying.FpPv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Conveying__FpSp = new NxtControl.Drawing.Font("SE.App2Conveying.FpSp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Conveying__FpText = new NxtControl.Drawing.Font("SE.App2Conveying.FpText", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Conveying__LabelFont = new NxtControl.Drawing.Font("SE.App2Conveying.LabelFont", new NxtControl.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2Conveying__SymText = new NxtControl.Drawing.Font("SE.App2Conveying.SymText", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2SingleLinePowerMonitoring__FpSp = new NxtControl.Drawing.Font("SE.App2SingleLinePowerMonitoring.FpSp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2SingleLinePowerMonitoring__LabelFont = new NxtControl.Drawing.Font("SE.App2SingleLinePowerMonitoring.LabelFont", new NxtControl.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2SingleLinePowerMonitoring__Pv = new NxtControl.Drawing.Font("SE.App2SingleLinePowerMonitoring.Pv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2SingleLinePowerMonitoring__Sp = new NxtControl.Drawing.Font("SE.App2SingleLinePowerMonitoring.Sp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2SingleLinePowerMonitoring__SymInstanceLabel = new NxtControl.Drawing.Font("SE.App2SingleLinePowerMonitoring.SymInstanceLabel", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2SingleLinePowerMonitoring__SymPv = new NxtControl.Drawing.Font("SE.App2SingleLinePowerMonitoring.SymPv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__App2SingleLinePowerMonitoring__SymSp = new NxtControl.Drawing.Font("SE.App2SingleLinePowerMonitoring.SymSp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__FpLabelFont = new NxtControl.Drawing.Font("SE.AppSequence.FpLabelFont", new NxtControl.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__FpPv = new NxtControl.Drawing.Font("SE.AppSequence.FpPv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__FpSp = new NxtControl.Drawing.Font("SE.AppSequence.FpSp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__FpText = new NxtControl.Drawing.Font("SE.AppSequence.FpText", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__LabelFont = new NxtControl.Drawing.Font("SE.AppSequence.LabelFont", new NxtControl.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__Pv = new NxtControl.Drawing.Font("SE.AppSequence.Pv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SALabel = new NxtControl.Drawing.Font("SE.AppSequence.SALabel", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SAPv = new NxtControl.Drawing.Font("SE.AppSequence.SAPv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SASp = new NxtControl.Drawing.Font("SE.AppSequence.SASp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__Sp = new NxtControl.Drawing.Font("SE.AppSequence.Sp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SymBAInstanceLabel = new NxtControl.Drawing.Font("SE.AppSequence.SymBAInstanceLabel", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SymInstanceLabel = new NxtControl.Drawing.Font("SE.AppSequence.SymInstanceLabel", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SymPv = new NxtControl.Drawing.Font("SE.AppSequence.SymPv", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SymSp = new NxtControl.Drawing.Font("SE.AppSequence.SymSp", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__SymText = new NxtControl.Drawing.Font("SE.AppSequence.SymText", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__AppSequence__Text = new NxtControl.Drawing.Font("SE.AppSequence.Text", new NxtControl.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__HwCommon__GroupActiveHeaderFont = new NxtControl.Drawing.Font("SE.HwCommon.GroupActiveHeaderFont", new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            SE__HwCommon__GroupInactiveHeaderFont = new NxtControl.Drawing.Font("SE.HwCommon.GroupInactiveHeaderFont", new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            Standard__IoModbus__SymbolCaptionFont = new NxtControl.Drawing.Font("Standard.IoModbus.SymbolCaptionFont", new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            ButtonFont = new NxtControl.Drawing.Font("ButtonFont", new NxtControl.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            CheckBoxFont = new NxtControl.Drawing.Font("CheckBoxFont", new NxtControl.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold), NxtControl.Drawing.DrawingObjectType.Project);
            RoundKnobFont = new NxtControl.Drawing.Font("RoundKnobFont", new NxtControl.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            TextBoxFont = new NxtControl.Drawing.Font("TextBoxFont", new NxtControl.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            ComboBoxFont = new NxtControl.Drawing.Font("ComboBoxFont", new NxtControl.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            TrackerValueFont = new NxtControl.Drawing.Font("TrackerValueFont", new NxtControl.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
            TrackerFont = new NxtControl.Drawing.Font("TrackerFont", new NxtControl.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular), NxtControl.Drawing.DrawingObjectType.Project);
        }
    }
}
